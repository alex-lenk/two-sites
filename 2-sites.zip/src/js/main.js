//= ../../bower_components/jquery/dist/jquery.js
//= ../../bower_components/bootstrap/dist/js/bootstrap.min.js
//= ../../bower_components/owlcarousel/owl-carousel/owl.carousel.min.js

/*
 * Custom
 */

$(function () {
    $('[data-toggle="tooltip"]').tooltip()
});

$(document).ready(function () {

    var prod = $("#producers");

    prod.owlCarousel({
        items: 5, //10 items above 1000px browser width
        itemsDesktop: [1000, 5], //5 items between 1000px and 901px
        itemsDesktopSmall: [900, 3], // betweem 900px and 601px
        itemsTablet: [600, 2], //2 items between 600 and 0
        itemsMobile: false // itemsMobile disabled - inherit from itemsTablet option

    });
    $(".next").click(function () {
        prod.trigger('owl.next');
    });
    $(".prev").click(function () {
        prod.trigger('owl.prev');
    });
});
